package com.example.myfirstkotlinapplication.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.myfirstkotlinapplication.R

class signupFragment : Fragment() {

    private lateinit var fullNameEditText: EditText
    private lateinit var emailOrPhoneEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var signUpButton: Button
    private lateinit var signInText: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_signup, container, false)

        fullNameEditText = view.findViewById(R.id.fullNameEditText)
        emailOrPhoneEditText = view.findViewById(R.id.emailOrPhoneEditText)
        passwordEditText = view.findViewById(R.id.passwordEditText)
        confirmPasswordEditText = view.findViewById(R.id.confirmPasswordEditText)
        signUpButton = view.findViewById(R.id.signupButton)
        signInText = view.findViewById(R.id.signUpText)

        signUpButton.setOnClickListener {
            val name = fullNameEditText.text.toString().trim()
            val email = emailOrPhoneEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val confirmPassword = confirmPasswordEditText.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else if (password != confirmPassword) {
                Toast.makeText(requireContext(), "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Registering...", Toast.LENGTH_SHORT).show()
            }
        }

        signInText.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, signinFragment())
                .addToBackStack(null)
                .commit()
        }

        return view
    }
}
