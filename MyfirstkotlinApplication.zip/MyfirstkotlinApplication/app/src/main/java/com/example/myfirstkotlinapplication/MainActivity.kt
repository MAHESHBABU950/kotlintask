package com.example.myfirstkotlinapplication

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myfirstkotlinapplication.ui.signinFragment
import com.example.myfirstkotlinapplication.ui.signupFragment

class MainActivity : AppCompatActivity() {

    private lateinit var signInTextView: TextView
    private lateinit var signUpTextView: TextView
    private lateinit var fbImageView: ImageView
    private lateinit var twitterImageView: ImageView
    private lateinit var instaImageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        signInTextView = findViewById(R.id.signintextView)
        signUpTextView = findViewById(R.id.signuptextView)
        fbImageView = findViewById(R.id.fbimageView2)
        twitterImageView = findViewById(R.id.twitterimageView2)
        instaImageView = findViewById(R.id.instaimageView2)

        signInTextView.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, signinFragment())
                .addToBackStack(null)
                .commit()
        }

        signUpTextView.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, signupFragment())
                .addToBackStack(null)
                .commit()
        }

        fbImageView.setOnClickListener {
            showToast("Facebook clicked")
        }

        twitterImageView.setOnClickListener {
            showToast("Twitter clicked")
        }

        instaImageView.setOnClickListener {
            showToast("Instagram clicked")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
